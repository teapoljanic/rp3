﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadatak3
{
    public partial class Form1 : Form
    {
        int v1 = 0, v2 = 0;
        List<Button> b1 = new List<Button>();
        List<Button> b2 = new List<Button>();
        int bilo = 0;
        int kliknuto = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            v2++;
            Button novi = new Button();
            novi.Location = new Point(45, v2 * 35);
            StringBuilder s = new StringBuilder();
            s.Append("Gumb").Append(v2.ToString());
            novi.Text = s.ToString();
            splitContainer1.Panel2.Controls.Add(novi);
            b2.Add(novi);
            novi.Click += new EventHandler(novi2_Click);
            bilo++;
            StringBuilder isp = new StringBuilder();
            isp.Append("Dodano ").Append(bilo.ToString()).Append(", kliknuto ").Append(kliknuto.ToString());
            toolStripStatusLabel1.Text = isp.ToString();
            Application.DoEvents();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            
            foreach(Button btn in b1)
            {
                btn.Click -= new EventHandler(this.novi_Click); //It's unnecessary
                this.Controls.Remove(btn);
                btn.Dispose();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            v1++;
            Button novi = new Button();
            novi.Location = new Point(12, v1*35);
            StringBuilder s = new StringBuilder();
            s.Append("Gumb").Append(v1.ToString());
            novi.Text = s.ToString();
            splitContainer1.Panel1.Controls.Add(novi);
            b1.Add(novi);
            novi.Click += new EventHandler(novi_Click);
            bilo++;
            StringBuilder isp = new StringBuilder();
            isp.Append("Dodano ").Append(bilo.ToString()).Append(", kliknuto ").Append(kliknuto.ToString());
            toolStripStatusLabel1.Text = isp.ToString();
            Application.DoEvents();
        }

        void novi_Click(object sender, EventArgs e)
        {
            kliknuto++;
            Button but = (Button)sender;
            String ime = but.Text;
            StringBuilder ispis = new StringBuilder();
            ispis.Append("Na lijevoj strani,").Append(ime);
            MessageBox.Show(ispis.ToString());
            StringBuilder isp = new StringBuilder();
            isp.Append("Dodano ").Append(bilo.ToString()).Append(", kliknuto ").Append(kliknuto.ToString());
            toolStripStatusLabel1.Text = isp.ToString();
            Application.DoEvents();
        }


        private void statusStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {
            StringBuilder isp = new StringBuilder();
            isp.Append("Dodano ").Append(bilo.ToString()).Append(", kliknuto ").Append(kliknuto.ToString());
            statusStrip1.Text = isp.ToString();
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (Button btn in b2)
            {
                btn.Click -= new EventHandler(this.novi2_Click); //It's unnecessary
                this.Controls.Remove(btn);
                btn.Dispose();
            }
        }

        void novi2_Click(object sender, EventArgs e)
        {
            kliknuto++;
            Button but = (Button)sender;
            String ime = but.Text;
            StringBuilder ispis = new StringBuilder();
            ispis.Append("Na desnoj strani,").Append(ime);
            MessageBox.Show(ispis.ToString());
            StringBuilder isp = new StringBuilder();
            isp.Append("Dodano ").Append(bilo.ToString()).Append(", kliknuto ").Append(kliknuto.ToString());
            toolStripStatusLabel1.Text = isp.ToString();
            Application.DoEvents();
        }
    }
}
